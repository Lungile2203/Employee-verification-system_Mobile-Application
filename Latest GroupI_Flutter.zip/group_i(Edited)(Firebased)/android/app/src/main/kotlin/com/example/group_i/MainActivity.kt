package com.example.group_i

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
