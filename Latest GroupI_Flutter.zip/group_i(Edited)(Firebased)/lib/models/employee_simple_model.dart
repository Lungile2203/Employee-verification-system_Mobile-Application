import 'package:cloud_firestore/cloud_firestore.dart';

class EmployeeSimple {
  final String id; // Firebase Auth UID
  final String email;
  final String name;
  final String surname;
  final String phone;
  final String? photoUrl;
  final String role;

  EmployeeSimple({
    required this.id,
    required this.email,
    required this.name,
    required this.surname,
    required this.phone,
    this.photoUrl,
    this.role = 'employee',
  });

  factory EmployeeSimple.fromMap(String id, Map<String, dynamic> data) {
    return EmployeeSimple(
      id: id,
      email: data['Email'] ?? '',
      name: data['Name'] ?? '',
      surname: data['Surname'] ?? '',
      phone: data['Phone'] ?? '',
      photoUrl: data['PhotoUrl'],
      role: data['Role'] ?? 'employee',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'Id': id,
      'Email': email,
      'Name': name,
      'Surname': surname,
      'Phone': phone,
      'PhotoUrl': photoUrl,
      'Role': role,
    };
  }
}
