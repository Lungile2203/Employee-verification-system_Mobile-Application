// models/user_model.dart
import 'dart:convert';

abstract class User {
  String userID;
  String name; // Changed from username
  String surname; // Added
  String email;
  String role;
  String? department;

  User({
    required this.userID,
    required this.name,
    required this.surname,
    required this.email,
    required this.role,
    this.department,
  });

  // Getter to provide a full name, useful for display purposes.
  String get fullName => '$name $surname'.trim();
}

class Employee extends User {
  String password;
  String phone;
  String status;
  String role; // Changed from jobTitle
  String? staffCardPhotoStatus;
  String? photoUrl;
  DateTime? lastClockIn;
  String? deletionReason;
  Map<String, double>? lastClockInLocation;
  bool isBiometricSetupComplete;

  Employee({
    required super.userID,
    required super.name,
    required super.surname,
    required super.email,
    required this.password,
    required this.phone,
    required this.status,
    this.role = '', // Changed from jobTitle
    this.staffCardPhotoStatus,
    this.photoUrl,
    this.lastClockIn,
    this.deletionReason,
    this.lastClockInLocation,
    this.isBiometricSetupComplete = false,
    super.department,
  }) : super(
         role: 'employee',
       );

  // Factory constructor to create an Employee from a map (Firestore data)
  factory Employee.fromMap(String userID, Map<String, dynamic> data) {
    return Employee(
      userID: userID,
      name: data['name'] ?? data['Name'] ?? '', // Support for 'name' and 'Name'
      email: data['email'] ?? '',
      surname: data['surname'] ?? data['Surname'] ?? '', // Support for 'surname' and 'Surname'
      password: data['password'] ?? '', // Be cautious with password handling
      phone: data['phone'] ?? '',
      status: data['status'] ?? 'unknown',
      role: data['role'] ?? '', // Changed from jobTitle
      department: data['department'] ?? '',
      staffCardPhotoStatus: data['staffCardPhotoStatus'],
      photoUrl: data['photoUrl'],
      lastClockIn: data['lastClockIn'] != null
          ? DateTime.tryParse(data['lastClockIn'] as String)
          : null,
      deletionReason: data['deletionReason'],
      lastClockInLocation: (data['lastClockInLocation'] != null)
          ? (data['lastClockInLocation'] is String
              ? Map<String, double>.from(
                  jsonDecode(data['lastClockInLocation']))
              : Map<String, double>.from(data['lastClockInLocation']))
          : null, 
      isBiometricSetupComplete: data['isBiometricSetupComplete'] ?? false,
    );
  }

  // Method to convert Employee object to a map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'surname': surname,
      'email': email,
      // 'password' is intentionally omitted for security
      'phone': phone,
      'status': status,
      'role': role, // Changed from jobTitle
      'department': department,
      'photoUrl': photoUrl,
      'staffCardPhotoStatus': staffCardPhotoStatus,
      'lastClockIn': lastClockIn?.toIso8601String(),
      'deletionReason': deletionReason,
      'lastClockInLocation': lastClockInLocation,
      'isBiometricSetupComplete': isBiometricSetupComplete,
    };
  }

  // Copy with method for easy updates
  Employee copyWith({
    String? name,
    String? surname,
    String? email,
    String? password,
    String? phone,
    String? status,
    String? role, // Changed from jobTitle
    String? staffCardPhotoStatus,
    String? photoUrl,
    DateTime? lastClockIn,
    String? department,
    String? deletionReason,
    Map<String, double>? lastClockInLocation,
    bool? isBiometricSetupComplete,
  }) {
    return Employee(
      userID: userID,
      name: name ?? this.name,
      surname: surname ?? this.surname,
      email: email ?? this.email,
      password: password ?? this.password,
      phone: phone ?? this.phone,
      status: status ?? this.status,
      role: role ?? this.role, // Changed from jobTitle
      staffCardPhotoStatus: staffCardPhotoStatus ?? this.staffCardPhotoStatus,
      photoUrl: photoUrl ?? this.photoUrl,
      lastClockIn: lastClockIn ?? this.lastClockIn,
      department: department ?? this.department,
      deletionReason: deletionReason ?? this.deletionReason,
      lastClockInLocation: lastClockInLocation ?? this.lastClockInLocation,
      isBiometricSetupComplete: isBiometricSetupComplete ?? this.isBiometricSetupComplete,
    );
  }
}

class Admin extends User {
  String password;
  // username is inherited as 'name'
  Admin({
    required super.userID,
    required super.name,
    required super.surname,
    required super.email,
    required this.password,
    required String super.department,
  }) : super(
         role: 'admin',
       );
  // Getter for compatibility if `username` is used elsewhere for Admins.
  String get username => name;
  Admin copyWith({
    String? name,
    String? surname,
    String? email,
    String? password,
    String? department,
  }) {
    return Admin(
      userID: userID,
      name: name ?? this.name,
      surname: surname ?? this.surname,
      email: email ?? this.email,
      password: password ?? this.password,
      department: department ?? this.department ?? '',
    );
  }
}
