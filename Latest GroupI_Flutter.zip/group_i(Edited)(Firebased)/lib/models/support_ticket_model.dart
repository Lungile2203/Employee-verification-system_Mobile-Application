// models/support_ticket_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class SupportTicket {
  final String id;
  final String employeeId;
  final String employeeName;
  final String subject;
  final String status;
  final DateTime createdAt;
  final DateTime lastUpdatedAt;
  final String lastMessage;

  SupportTicket({
    required this.id,
    required this.employeeId,
    required this.employeeName,
    required this.subject,
    required this.status,
    required this.createdAt,
    required this.lastUpdatedAt,
    required this.lastMessage,
  });

  factory SupportTicket.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return SupportTicket(
      id: doc.id,
      employeeId: data['employeeId'] ?? '',
      employeeName: data['employeeName'] ?? 'Unknown',
      subject: data['subject'] ?? 'No Subject',
      status: data['status'] ?? 'open',
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      lastUpdatedAt: (data['lastUpdatedAt'] as Timestamp).toDate(),
      lastMessage: data['lastMessage'] ?? '',
    );
  }
}

class TicketMessage {
  final String id;
  final String senderId;
  final String senderRole;
  final String message;
  final DateTime timestamp;

  TicketMessage(
      {required this.id, required this.senderId, required this.senderRole, required this.message, required this.timestamp});

  factory TicketMessage.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return TicketMessage(
      id: doc.id,
      senderId: data['senderId'] ?? '',
      senderRole: data['senderRole'] ?? '',
      message: data['message'] ?? '',
      timestamp: (data['timestamp'] as Timestamp).toDate(),
    );
  }
}