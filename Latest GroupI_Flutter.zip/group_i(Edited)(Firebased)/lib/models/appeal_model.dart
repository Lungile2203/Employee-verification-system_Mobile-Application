import 'package:cloud_firestore/cloud_firestore.dart';

class AppealModel {
  final String id;
  final String uid;
  final String verificationId;
  final String status; // pending, approved, rejected
  final DateTime createdAt;
  final DateTime? reviewedAt;
  final String? comment;

  AppealModel({
    required this.id,
    required this.uid,
    required this.verificationId,
    required this.status,
    required this.createdAt,
    this.reviewedAt,
    this.comment,
  });

  factory AppealModel.fromMap(String id, Map<String, dynamic> data) {
    return AppealModel(
      id: id,
      uid: data['uid'] ?? '',
      verificationId: data['verificationId'] ?? '',
      status: data['status'] ?? 'pending',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      reviewedAt: (data['reviewedAt'] as Timestamp?)?.toDate(),
      comment: data['comment'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'verificationId': verificationId,
      'status': status,
      'createdAt': FieldValue.serverTimestamp(),
      'reviewedAt': reviewedAt != null ? reviewedAt!.toIso8601String() : null,
      'comment': comment,
    };
  }
}
