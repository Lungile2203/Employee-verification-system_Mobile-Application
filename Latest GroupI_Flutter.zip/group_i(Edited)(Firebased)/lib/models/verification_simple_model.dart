import 'package:cloud_firestore/cloud_firestore.dart';

class VerificationSimple {
  final String id; // Firestore doc id
  final String uid; // employee uid
  final String employeeEmail;
  final String idDocumentUrl; // public download url
  final String proofUrl;
  final String selfieUrl;
  final String status; // pending, approved, rejected
  final DateTime createdAt;
  final DateTime? reviewedAt;
  final String? comment;
  final String? appealMessage;

  VerificationSimple({
    required this.id,
    required this.uid,
    required this.employeeEmail,
    required this.idDocumentUrl,
    required this.proofUrl,
    required this.selfieUrl,
    required this.status,
    required this.createdAt,
    this.reviewedAt,
    this.comment,
    this.appealMessage,
  });

  factory VerificationSimple.fromMap(String id, Map<String, dynamic> data) {
    return VerificationSimple(
      id: id,
      uid: data['uid'] ?? '',
      employeeEmail: data['employeeEmail'] ?? '',
      idDocumentUrl: data['idDocumentUrl'] ?? '',
      proofUrl: data['proofUrl'] ?? '',
      selfieUrl: data['selfieUrl'] ?? '',
      status: data['status'] ?? 'pending',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      reviewedAt: (data['reviewedAt'] as Timestamp?)?.toDate(),
      comment: data['comment'],
      appealMessage: data['appealMessage'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'employeeEmail': employeeEmail,
      'idDocumentUrl': idDocumentUrl,
      'proofUrl': proofUrl,
      'selfieUrl': selfieUrl,
      'status': status,
      'createdAt': FieldValue.serverTimestamp(),
      'reviewedAt': reviewedAt != null ? reviewedAt!.toIso8601String() : null,
      'comment': comment,
      'appealMessage': appealMessage,
    };
  }
}
