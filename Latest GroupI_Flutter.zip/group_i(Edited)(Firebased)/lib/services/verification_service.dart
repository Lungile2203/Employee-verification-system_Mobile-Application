import 'dart:io';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb_auth;
import 'package:flutter/foundation.dart';

import '../models/verification_simple_model.dart';

class VerificationService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final fb_auth.FirebaseAuth _auth = fb_auth.FirebaseAuth.instance;

  CollectionReference get _verifications => _firestore.collection('verifications');
  CollectionReference get _appeals => _firestore.collection('appeals');

  /// Get the most recent verification for the current user
  Future<Map<String, dynamic>> getEmployeeVerification() async {
    final user = _auth.currentUser;
    if (user == null) return {'hasVerification': false};

    final snapshot = await _verifications.where('uid', isEqualTo: user.uid).orderBy('createdAt', descending: true).limit(1).get();
    if (snapshot.docs.isEmpty) return {'hasVerification': false};

    final doc = snapshot.docs.first;
    final verification = VerificationSimple.fromMap(doc.id, doc.data() as Map<String, dynamic>);
    return {'hasVerification': true, 'verification': verification};
  }

  /// Get a stream of the most recent verification for the current user
  Stream<Map<String, dynamic>> getEmployeeVerificationStream() {
    final user = _auth.currentUser;
    if (user == null) return Stream.value({'hasVerification': false});

    return _verifications.where('uid', isEqualTo: user.uid).orderBy('createdAt', descending: true).limit(1).snapshots().map((snapshot) {
      if (snapshot.docs.isEmpty) {
        return {'hasVerification': false};
      }

      final doc = snapshot.docs.first;
      final verification = VerificationSimple.fromMap(doc.id, doc.data() as Map<String, dynamic>);
      return {'hasVerification': true, 'verification': verification};
    });
  }



  /// Submit verification files. Stores files in Firebase Storage and creates a Firestore document.
  /// Files size is validated (<= 50MB) and allowed types are checked by extension.
  Future<Map<String, dynamic>> submitVerification({ // Changed to PlatformFile
    required PlatformFile idFile,
    required PlatformFile proofFile,
    required PlatformFile selfieFile,
  }) async {
    final user = _auth.currentUser;
    if (user == null) return {'success': false, 'message': 'Not authenticated.'};

    // Validate sizes (<= 50MB)
    final maxBytes = 50 * 1024 * 1024;
    if (idFile.size > maxBytes || proofFile.size > maxBytes || selfieFile.size > maxBytes) { // Use PlatformFile.size
      return {'success': false, 'message': 'One or more files exceeds 50MB limit.'};
    }

    // Validate extensions
    bool _allowed(String name) {
      final lower = name.toLowerCase();
      return lower.endsWith('.jpg') || lower.endsWith('.jpeg') || lower.endsWith('.png') || lower.endsWith('.pdf'); // Check name
    }

    if (!_allowed(idFile.name) || !_allowed(proofFile.name) || !_allowed(selfieFile.name)) { // Check name
      return {'success': false, 'message': 'Unsupported file format. Allowed: JPG, JPEG, PNG, PDF.'};
    }

    try {
      // Generate a timestamp+random ID for file names
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final rand = Random().nextInt(1000000);
      final basePath = 'verifications/${user.uid}';
      
      final idName = 'id_${timestamp}_$rand${_ext(idFile.name)}'; // Use PlatformFile.name
      final proofName = 'proof_${timestamp}_$rand${_ext(proofFile.name)}'; // Use PlatformFile.name
      final selfieName = 'selfie_${timestamp}_$rand${_ext(selfieFile.name)}'; // Use PlatformFile.name

      final idRef = _storage.ref().child('$basePath/$idName');
      final proofRef = _storage.ref().child('$basePath/$proofName');
      final selfieRef = _storage.ref().child('$basePath/$selfieName');

      // Upload
      UploadTask upload1;
      UploadTask upload2;
      UploadTask upload3;

      // Conditionally use putFile (mobile) or putData (web)
      upload1 = idFile.bytes != null ? idRef.putData(idFile.bytes!) : idRef.putFile(File(idFile.path!));
      upload2 = proofFile.bytes != null ? proofRef.putData(proofFile.bytes!) : proofRef.putFile(File(proofFile.path!));
      upload3 = selfieFile.bytes != null ? selfieRef.putData(selfieFile.bytes!) : selfieRef.putFile(File(selfieFile.path!));

      await Future.wait([upload1, upload2, upload3].map((t) => t.whenComplete(() {}))); // Wait for uploads to complete

      // Get download URLs
      final idDownloadUrl = await idRef.getDownloadURL();
      final proofDownloadUrl = await proofRef.getDownloadURL();
      final selfieDownloadUrl = await selfieRef.getDownloadURL();

      // Store download URLs in Firestore
      // The user's Firestore data shows 'idDocumentUrl', 'proofUrl', 'selfieUrl'
      // So we will store the download URLs directly.

      final verificationData = {
        'uid': user.uid,
        'employeeEmail': user.email ?? '',
        'idDocumentUrl': idDownloadUrl,
        'proofUrl': proofDownloadUrl,
        'selfieUrl': selfieDownloadUrl,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
        'reviewedAt': null,
        'comment': null,
        'appealMessage': null,
      };

      // Explicitly create the document in the verifications collection
      final docRef = await _firestore.collection('verifications').add(verificationData);

      // Also create records under employees/{uid}/documents so the SubmittedDocumentsScreen
      // (which reads employees/{uid}/documents) can display the files consistently.
      try {
        final docsCollection = _firestore.collection('employees').doc(user.uid).collection('documents');
        final now = FieldValue.serverTimestamp();

        await docsCollection.add({
          'requestId': user.uid,
          'documentType': 'id_copy',
          'filePath': idDownloadUrl,
          'fileName': idName,
          'fileSize': '0 MB',
          'uploadDate': now,
          'status': 'uploaded',
        });

        await docsCollection.add({
          'requestId': user.uid,
          'documentType': 'employment_proof',
          'filePath': proofDownloadUrl,
          'fileName': proofName,
          'fileSize': '0 MB',
          'uploadDate': now,
          'status': 'uploaded',
        });

        await docsCollection.add({
          'requestId': user.uid,
          'documentType': 'selfie',
          'filePath': selfieDownloadUrl,
          'fileName': selfieName,
          'fileSize': '0 MB',
          'uploadDate': now,
          'status': 'uploaded',
        });
      } catch (e) {
        if (kDebugMode) print('Warning: failed to create employee document records: $e');
      }

      return {
        'success': true,
        'message': 'Verification submitted.',
        'docId': docRef.id,
        'idDocumentUrl': idDownloadUrl,
        'proofUrl': proofDownloadUrl,
        'selfieUrl': selfieDownloadUrl,
      };
    } catch (e, st) {
      if (kDebugMode) print('submitVerification error: $e $st');
      return {'success': false, 'message': 'Upload failed.'};
    }
  }

  /// Upload a single document and update the verification record in Firestore.
  Future<Map<String, dynamic>> submitSingleDocument({
    required PlatformFile file,
    required String documentType, // 'idDocument', 'proof', 'selfie'
  }) async {
    final user = _auth.currentUser;
    if (user == null) return {'success': false, 'message': 'Not authenticated.'};

    // Validate file size and type
    final maxBytes = 50 * 1024 * 1024;
    if (file.size > maxBytes) {
      return {'success': false, 'message': 'File exceeds 50MB limit.'};
    }

    try {
      // Find the existing verification document
      final query = await _verifications.where('uid', isEqualTo: user.uid).limit(1).get();
      if (query.docs.isEmpty) {
        return {'success': false, 'message': 'No verification record found. Please submit all documents first.'};
      }
      final docRef = query.docs.first.reference;

      // Upload file to storage
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final rand = Random().nextInt(1000000);
      final basePath = 'verifications/${user.uid}';
      final fileName = '${documentType}_${timestamp}_$rand${_ext(file.name)}';
      final storageRef = _storage.ref().child('$basePath/$fileName');

      UploadTask uploadTask = file.bytes != null
          ? storageRef.putData(file.bytes!)
          : storageRef.putFile(File(file.path!));

      await uploadTask.whenComplete(() {});
      final downloadUrl = await storageRef.getDownloadURL();

      // Update the specific URL field in the Firestore document
      final fieldToUpdate = '${documentType}Url'; // e.g., 'idDocumentUrl'
      await docRef.update({
        fieldToUpdate: downloadUrl,
        'status': 'pending', // Reset status to pending on new upload
        'lastUpdatedAt': FieldValue.serverTimestamp(),
      });

      return {'success': true, 'message': '$documentType uploaded successfully.', 'url': downloadUrl};
    } catch (e, st) {
      if (kDebugMode) print('submitSingleDocument error: $e $st');
      return {'success': false, 'message': 'Upload failed.'};
    }
  }

  Future<Map<String, dynamic>> appealVerification({required String verificationId, required String message}) async {
    final user = _auth.currentUser;
    if (user == null) return {'success': false, 'message': 'Not authenticated.'};

    try {
      final appealRef = await _appeals.add({
        'uid': user.uid,
        'verificationId': verificationId,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
        'reviewedAt': null,
        'comment': message,
      });

      // Update verification to pending and set appealMessage
      await _verifications.doc(verificationId).update({'status': 'pending', 'appealMessage': message});

      return {'success': true, 'message': 'Appeal submitted.', 'appealId': appealRef.id};
    } catch (e) {
      if (kDebugMode) print('appealVerification error: $e');
      return {'success': false, 'message': 'Appeal failed.'};
    }
  }

  String _ext(String fileName) { // Changed to accept fileName
    final idx = fileName.lastIndexOf('.');
    return idx >= 0 ? fileName.substring(idx) : '';
  }
}
