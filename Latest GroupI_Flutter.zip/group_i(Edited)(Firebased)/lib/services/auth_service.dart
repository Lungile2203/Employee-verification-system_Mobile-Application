// services/auth_service.dart
import '../models/verification_model.dart';
import '../models/support_ticket_model.dart';
import '../models/activity_log_model.dart';
import '../models/user_model.dart';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb_auth;
import 'dart:math';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import 'package:intl/intl.dart' as intl;
import 'package:async/async.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal() {
    // Listen to auth state changes to automatically load/clear user data and notify listeners.
    _firebaseAuth.authStateChanges().listen(_onAuthStateChangedAndNotify);
  }

  final fb_auth.FirebaseAuth _firebaseAuth = fb_auth.FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  User? _currentUser;

  // A controller to broadcast the current user state.
  final StreamController<User?> _userController = StreamController<User?>.broadcast();

  // Define a typed reference to the 'verifications' collection
  CollectionReference<Employee> get _verificationsCollection =>
      _firestore.collection('verifications').withConverter<Employee>(
            fromFirestore: (snapshot, _) => Employee.fromMap(snapshot.id, snapshot.data()!),
            toFirestore: (employee, _) => employee.toMap(),
          );

  // Define a typed reference to the 'employees' collection for consistency
  CollectionReference<Employee> get _employeesCollection =>
      _firestore.collection('employees').withConverter<Employee>(
          fromFirestore: (snapshot, _) => Employee.fromMap(snapshot.id, snapshot.data()!), toFirestore: (employee, _) => employee.toMap());

  // A stream that emits the current user when the auth state changes
  Stream<User?> get onUserChanged => _userController.stream;

  User? get currentUser => _currentUser;

  bool get isLoggedIn => _currentUser != null;
  bool get isAdmin => _currentUser?.role == 'admin';
  bool get isEmployee => _currentUser?.role == 'employee';

  Future<String> login({
    required String role,
    String? email,
    String? employeeId,
    String? loginIdentifier,
    required String password,
  }) async {
    // Determine the email to use for login.
    // For employees, they might use a username/ID. For admins, it's always email.
    String? loginEmail = email;

    if (role == 'employee' && loginIdentifier != null) {
      // If loginIdentifier is provided for an employee, and it contains '@',
      // assume it's an email and use it directly.
      if (loginEmail == null && loginIdentifier.contains('@')) {
        loginEmail = loginIdentifier;
        // No need to query Firestore here, as Firebase Auth will validate the email.
      }
    }

    // If no email is found or provided, login cannot proceed.
    if (loginEmail == null || loginEmail.isEmpty) {
      return "User not found. Please check your credentials.";
    }

    try {
      // Use Firebase Auth to sign in the user with their email and password.
      final userCredential = await _firebaseAuth.signInWithEmailAndPassword(
        email: loginEmail,
        password: password,
      );

      // --- FIX B: Explicitly fetch user document after login for robustness ---
      final firebaseUser = userCredential.user;
      if (firebaseUser != null) {
        print("Login successful for UID: ${firebaseUser.uid}. Explicitly fetching user document.");
        
        DocumentSnapshot? doc;
        final docById = await _employeesCollection.doc(firebaseUser.uid).get();

        if (docById.exists) {
          doc = docById;
        } else {
          print("Employee doc not found by UID. Falling back to query by employeeID or email.");
          if (firebaseUser.email != null) {
            final q2 = await _employeesCollection.where('email', isEqualTo: firebaseUser.email!).limit(1).get();
            if (q2.docs.isNotEmpty) doc = q2.docs.first;
          }
        }

        if (doc != null && doc.exists) {
          print("Successfully found employee document with ID: ${doc.id}. Setting current user.");
          _currentUser = Employee.fromMap(doc.id, doc.data() as Map<String, dynamic>);
          _userController.add(_currentUser); // Explicitly notify listeners
        } else {
          print("Could not find an employee document in 'employees' or 'verifications' for UID ${firebaseUser.uid}.");
          // Fallback to the standard auth state change handler which also checks admins.
          await _onAuthStateChangedAndNotify(firebaseUser);
        }
      } else {
        // This case is unlikely but handled for safety.
        await _onAuthStateChangedAndNotify(firebaseUser);
      }
      // --- END FIX B ---

      // Manually trigger the user load and notify listeners upon successful login.
      // This ensures the AuthWrapper will pick up the change and navigate.

      return "Success";

    } on fb_auth.FirebaseAuthException catch (e) {
      print("Firebase Auth Error on login: ${e.code} - ${e.message}");
      if (e.code == 'user-not-found' || e.code == 'invalid-credential' || e.code == 'wrong-password') {
        return "Login failed. Please check your credentials.";
      }
      return "An unknown error occurred during login.";
    }
  }

  // Private method to handle auth state changes
  Future<void> _onAuthStateChangedAndNotify(fb_auth.User? firebaseUser) async {
    if (firebaseUser == null) {
      _currentUser = null;
    } else {
      await _loadCurrentUser(firebaseUser.uid);
    }
    _userController.add(_currentUser);
  }

  // Helper to load user data from Firestore after login
  Future<void> _loadCurrentUser(String uid) async {
    print("Auth state changed. Loading current user for UID: $uid");
    // First, check if the user is an admin.
    DocumentSnapshot adminDoc = await _firestore.collection('admins').doc(uid).get();
    if (adminDoc.exists) {
      final data = adminDoc.data() as Map<String, dynamic>;
      _currentUser = Admin(
        userID: uid,
        name: data['username'] ?? 'Admin', // Use 'username' from DB for 'name'
        surname: data['surname'] ?? '', // Admins may not have a separate surname field
        email: data['email'] ?? '',
        password: '', // Do not store password
        department: data['department'] ?? 'N/A',
      );
    } else {
      // If not an admin, check if they are an employee.
      var employeeDoc = await _employeesCollection.doc(uid).get();
      if (employeeDoc.exists) {
        _currentUser = employeeDoc.data();
      } else {
        // --- FIX A: Robust fallback for _loadCurrentUser ---
        print("User doc not found by UID in 'employees'. Checking 'verifications' and then falling back to query.");
        var verificationDoc = await _verificationsCollection.doc(uid).get();
        if (verificationDoc.exists) {
          _currentUser = verificationDoc.data();
        } else {
          print("User doc not found by UID in 'verifications' either. Fallback: querying by email.");
          final firebaseUser = _firebaseAuth.currentUser;
          if (firebaseUser?.email != null) {
            var query = await _employeesCollection.where('email', isEqualTo: firebaseUser!.email).limit(1).get();
            if (query.docs.isNotEmpty) {
              print("Found user by email in 'employees' collection.");
              _currentUser = query.docs.first.data();
            } else {
              query = await _verificationsCollection.where('email', isEqualTo: firebaseUser.email).limit(1).get();
              if (query.docs.isNotEmpty) {
                print("Found user by email in 'verifications' collection.");
                _currentUser = query.docs.first.data();
              }
            }
          }
        }
        // --- END FIX A ---
      }
    }
  }

  Future<String?> getEmailFromLoginIdentifier(String identifier) async {
    // This method is now obsolete since employeeID is removed.
    // Login will rely on email.
    return identifier.contains('@') ? identifier : null;
  }

  Future<Employee?> getEmployeeByUid(String uid) async {
    try {
      var doc = await _employeesCollection.doc(uid).get();
      if (doc.exists) {
        return doc.data();
      }
      // If not in employees, check verifications
      doc = await _verificationsCollection.doc(uid).get();
      if (doc.exists) {
        return doc.data();
      }

      return null;
    } catch (e) {
      print("Error fetching employee by UID: $e");
      return null;
    }
  }

  Future<bool> updateEmployeeProfile(Employee updatedEmployee) async {
    // Allow update if the current user is an admin, or if the employee is updating their own profile.
    if (!isAdmin && (_currentUser == null || _currentUser!.userID != updatedEmployee.userID)) {
      return false; // Not an admin and not updating own profile
    }

    // If an admin is approving a user, we move them from 'verifications' to 'employees'
    if (isAdmin && updatedEmployee.status == 'approved') {
      try {
        // Get the original document from verifications
        final verificationDoc = await _verificationsCollection.doc(updatedEmployee.userID).get();
        if (verificationDoc.exists) {
          // Create in 'employees' collection
          await _employeesCollection.doc(updatedEmployee.userID).set(updatedEmployee);
          // Delete from 'verifications' collection
          await _verificationsCollection.doc(updatedEmployee.userID).delete();
          return true;
        }
        return false; // Original document not found
      } catch (e) {
        print("Error moving employee from verification to employees: $e");
        return false;
      }
    }

    try {
      // Determine which collection to update based on user status
      final collection = updatedEmployee.status == 'approved' ? 'employees' : 'verifications';
      await _firestore.collection(collection).doc(updatedEmployee.userID).update(updatedEmployee.toMap());

      // Do NOT change the current user if an admin is making the change.
      if (_currentUser?.userID == updatedEmployee.userID) {
        _currentUser = updatedEmployee; // Update local state
        _userController.add(_currentUser); // Notify listeners of the change
      }
      return true;
    } catch (e) {
      print("Error updating employee profile: $e");
      return false;
    }
  }

  Future<bool> updateAdminProfile(Admin updatedAdmin) async {
    // Mock API call to update profile
    await Future.delayed(const Duration(seconds: 2));

    if (_currentUser is Admin) {
      _currentUser = updatedAdmin;
      return true;
    }
    return false;
  }

  Future<void> logout() async {
    // For all users, signing out from Firebase will trigger the auth state listener,
    // which will clear the user and navigate to the login screen.
    await _firebaseAuth.signOut();
  }

  Future<bool> sendPasswordResetEmail(String email) async {
    try {
      await _firebaseAuth.sendPasswordResetEmail(email: email);
      return true;
    } on fb_auth.FirebaseAuthException catch (e) {
      print("Error sending password reset email: $e");
      return false;
    }
  }

  Future<String> changePassword(
      String oldPassword, String newPassword) async {
    final user = _firebaseAuth.currentUser;
    final email = user?.email;

    if (user == null || email == null) {
      return "User not found. Please log in again.";
    }

    try {
      // Re-authenticate the user with their old password
      final cred =
          fb_auth.EmailAuthProvider.credential(email: email, password: oldPassword);
      await user.reauthenticateWithCredential(cred);

      // If re-authentication is successful, update the password
      await user.updatePassword(newPassword);

      return "Success";
    } on fb_auth.FirebaseAuthException catch (e) {
      if (e.code == 'wrong-password' || e.code == 'invalid-credential') {
        return "Incorrect old password. Please try again.";
      }
      print("Error changing password: $e");
      return "An error occurred. Please try again later.";
    }
  }

  Future<bool> submitVerificationDocuments({
    required File idDocument,
    required File selfiePhoto,
    required File employmentProof,
  }) async {
    if (_currentUser == null) return false;
    final userId = _currentUser!.userID;

    try {
      // Upload each document and create a record in Firestore.
      await _uploadAndCreateDocumentRecord(userId, idDocument, 'id_copy');
      await _uploadAndCreateDocumentRecord(userId, selfiePhoto, 'selfie');
      await _uploadAndCreateDocumentRecord(userId, employmentProof, 'employment_proof');

      // After submitting, update the employee's status to 'under_review'.
      await _firestore.collection('employees').doc(userId).update({'status': 'under_review'});
      await logActivity('Employee submitted verification documents.');
      return true;
    } catch (e) {
      print("Error submitting verification documents: $e");
      return false;
    }
  }

  Future<void> _uploadAndCreateDocumentRecord(String userId, File file, String docType) async {
    // 1. Upload file to Firebase Storage
    final fileName = '${docType}_${DateTime.now().millisecondsSinceEpoch}';
    final storageRef = _storage.ref().child('user_documents/$userId/$fileName');
    final uploadTask = await storageRef.putFile(file);
    final downloadUrl = await uploadTask.ref.getDownloadURL();

    // 2. Create a document record in Firestore
    final docRecord = DocumentUpload(
      uploadId: '', // Firestore will generate this
      requestId: userId, // Link to the user
      documentType: docType,
      filePath: downloadUrl, // Store the public URL
      fileName: fileName,
      fileSize: '${(await file.length() / 1024 / 1024).toStringAsFixed(2)} MB',
      uploadDate: DateTime.now(), // This will be replaced by server timestamp
    );

    await _firestore
        .collection('employees')
        .doc(userId)
        .collection('documents')
        .add(docRecord.toMap());
  }

  Stream<List<Employee>> getVerifiableEmployeesStream() {
    // Combine streams from both 'verifications' and 'employees' collections
    // to get a complete list of all users for admin views.
    final verificationsStream = _verificationsCollection.snapshots();
    final employeesStream = _employeesCollection.snapshots();

    return StreamZip([verificationsStream, employeesStream]).map((snapshots) {
      final verificationDocs = snapshots[0].docs;
      final employeeDocs = snapshots[1].docs;

      final List<Employee> allEmployees = [];

      // Add employees from verifications (withConverter handles mapping)
      allEmployees.addAll(verificationDocs.map((doc) => doc.data()).where((e) => e.status != 'deleted'));

      // Add employees from employees collection (withConverter handles mapping)
      allEmployees.addAll(employeeDocs.map((doc) => doc.data()).where((e) => e.status != 'deleted'));

      return allEmployees;
    }).asBroadcastStream(); // Use asBroadcastStream if listened to in multiple places
  }

  Future<bool> updateEmployeeStatus(String employeeUid, String newStatus) async {
    // For mock admin, we can't update Firestore due to permissions.
    // We will simulate a successful update for a better UX during testing.
    if (isAdmin) {
      await Future.delayed(const Duration(seconds: 1));
      print('Mock Admin: Simulating status update for $employeeUid to $newStatus');
      return true;
    }
    try {
      await _employeesCollection.doc(employeeUid)
          .update({'status': newStatus});
      // If the updated user is the current user, refresh local data
      if (_currentUser?.userID == employeeUid) {
        await _loadCurrentUser(employeeUid);
        _userController.add(_currentUser);
      }
      return true;
    } catch (e) {
      print("Error updating employee status: $e");
      return false;
    }
  }

  Future<List<DocumentUpload>> getDocumentsForEmployee(String employeeId) {
    return _employeesCollection
        .doc(employeeId)
        .collection('documents')
        .orderBy('uploadDate', descending: true)
        .get()
        .then((snapshot) => snapshot.docs
            .map((doc) => DocumentUpload.fromMap(doc.id, doc.data()))
            .toList());
  }

  Future<void> logActivity(String message) async {
    try {
      await _firestore.collection('activity_logs').add({
        'message': message,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print("Error logging activity: $e");
    }
  }

  Stream<List<ActivityLog>> getActivityLogs() {
    return _firestore
        .collection('activity_logs')
        .orderBy('timestamp', descending: true)
        .limit(100) // Get the last 100 activities
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => ActivityLog.fromFirestore(doc))
            .toList());
  }

  Stream<List<ActivityLog>> getScanActivityLogs() {
    return _firestore
        .collection('activity_logs')
        .orderBy('timestamp', descending: true)
        .limit(200) // Fetch a larger batch to filter on the client
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => ActivityLog.fromFirestore(doc))
          // Filter for messages that start with the clock-in prefix
          .where((log) => log.message.startsWith('Admin clocked in'))
          .toList();
    });
  }

  Stream<Map<String, int>> getDashboardStats() {
    return _employeesCollection.snapshots().map((snapshot) {
      int total = 0;
      int pending = 0;
      int approved = 0;
      int rejected = 0;

      total = snapshot.docs.length;

      for (var doc in snapshot.docs) {
        final status = doc.data().status;
        switch (status) {
          case 'registered':
            pending++;
            break;
          case 'approved':
            approved++;
            break;
          case 'rejected':
            rejected++;
            break;
        }
      }
      // 'Approved Today' would require storing an approval timestamp.
      // For now, we'll just show the total approved count.
      return {
        'total': total, 'pending': pending, 'approved': approved, 'rejected': rejected
      };
    });
  }

  Future<bool> requestStaffCardPhoto(String employeeId) async {
    try {
      await _employeesCollection
          .doc(employeeId)
          .update({'staffCardPhotoStatus': 'requested'});
      return true;
    } catch (e) {
      print("Error requesting staff card photo: $e");
      return false;
    }
  }

  String _generateRandomPassword() {
    const String lower = 'abcdefghijklmnopqrstuvwxyz';
    const String upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const String numbers = '0123456789';
    const String special = '!@#\$%^&*()';
    const String allChars = lower + upper + numbers + special;

    Random random = Random.secure();
    String password = '';

    // Ensure at least one of each required type for strength
    password += lower[random.nextInt(lower.length)];
    password += upper[random.nextInt(upper.length)];
    password += numbers[random.nextInt(numbers.length)];
    password += special[random.nextInt(special.length)];

    // Fill the rest of the password length (e.g., to 12 total characters)
    for (int i = 0; i < 8; i++) {
      password += allChars[random.nextInt(allChars.length)];
    }
    return password;
  }

  Future<String> createEmployeeByAdmin({
    required String name,
    required String surname,
    required String email,
    required String role,
  }) async {
    try {
      // New user validation is primarily handled by Firebase Authentication for email uniqueness.
      // Additional checks for existing records in 'verifications' or 'employees' can be added if needed,
      // but 'employeeID' is no longer a field.

      // 1. Create user in Firebase Authentication with a temporary random password
      final tempPassword = _generateRandomPassword();
      final userCredential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: tempPassword,
      );
      final newUser = userCredential.user;

      if (newUser != null) {
        // 2. Create the employee document in the 'verifications' collection
        final newEmployee = Employee(
          userID: newUser.uid, // Use the UID from Firebase Auth
          email: email,
          password: '', // Password is not stored in Firestore
          name: name,
          surname: surname,
          phone: '',
          status: 'registered',
          role: role, // Changed from jobTitle
          isBiometricSetupComplete: false, // New users need to set up biometrics
        );
        await _verificationsCollection.doc(newUser.uid).set(newEmployee);

        // 3. Immediately send a password reset email
        await sendPasswordResetEmail(email);

        await logActivity('Admin created profile for ${newEmployee.fullName}.');
        return 'Employee created successfully. A password setup email has been sent.';
      }
      return 'Failed to create user in Firebase Authentication.';
    } catch (e) {
      print("Error creating employee by admin: $e");
      return 'An unexpected error occurred.';
    }
  }

  Future<bool> clockInEmployee(String employeeId, DateTime clockInTime, Map<String, double>? location) async {
    if (!isAdmin) return false;

    try {
      final employeeDoc = await _employeesCollection.doc(employeeId).get();
      if (!employeeDoc.exists) return false;

      final employeeName = employeeDoc.data()?.fullName ?? 'Unknown';

      await _firestore.collection('employees').doc(employeeId).update({
        'lastClockIn': clockInTime.toIso8601String(),
        'lastClockInLocation': location,
      });

      String logMessage = 'Admin clocked in $employeeName at ${intl.DateFormat('yyyy-MM-dd - hh:mm a').format(clockInTime)}.';
      if (location != null) {
        logMessage += ' from location: ${location['latitude']?.toStringAsFixed(5)}, ${location['longitude']?.toStringAsFixed(5)}.';
      }
      await logActivity(logMessage);
      return true;
    } catch (e) {
      print("Error during employee clock-in: $e");
      return false;
    }
  }

  Future<bool> deleteEmployeeProfile(String employeeId, String reason) async {
    if (!isAdmin) {
      return false; // Only admins can delete profiles.
    }

    try {
      // Get employee details to log username before deletion
      final doc = await _employeesCollection.doc(employeeId).get();
      final fullName = doc.data()?.fullName ?? 'Unknown';

      await _employeesCollection.doc(employeeId).update({
        'status': 'deleted', // Note: This is a soft delete.
        'deletionReason': reason,
        'deletedAt': FieldValue.serverTimestamp(), // Keep track of when it was deleted
      });
      await logActivity('Admin deleted profile for $fullName for reason: $reason.');
      return true;
    } catch (e) {
      print("Error deleting employee profile: $e");
      return false;
    }
  }

  // --- Support Ticket System ---

  Future<bool> createSupportTicket({required String subject, required String message}) async {
    if (!isEmployee || _currentUser == null) return false;

    final employee = _currentUser as Employee;

    try {
      // Create the main ticket document
      final ticketRef = _firestore.collection('support_tickets').doc();
      await ticketRef.set({
        'employeeId': employee.userID,
        'employeeName': employee.fullName,
        'subject': subject,
        'status': 'open',
        'createdAt': FieldValue.serverTimestamp(),
        'lastUpdatedAt': FieldValue.serverTimestamp(),
        'lastMessage': message,
      });

      // Add the first message to the subcollection
      await ticketRef.collection('messages').add({
        'senderId': employee.userID,
        'senderRole': 'employee',
        'message': message,
        'timestamp': FieldValue.serverTimestamp(),
      });

      await logActivity('Employee ${employee.fullName} created a support ticket: "$subject"');
      return true;
    } catch (e) {
      print("Error creating support ticket: $e");
      return false;
    }
  }

  Stream<List<SupportTicket>> getEmployeeSupportTickets() {
    if (!isEmployee || _currentUser == null) return Stream.value([]);
    return _firestore
        .collection('support_tickets')
        .where('employeeId', isEqualTo: _currentUser!.userID)
        .orderBy('lastUpdatedAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => SupportTicket.fromFirestore(doc)).toList());
  }

  Stream<List<SupportTicket>> getAllSupportTickets() {
    if (!isAdmin) return Stream.value([]);
    return _firestore
        .collection('support_tickets')
        .orderBy('lastUpdatedAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => SupportTicket.fromFirestore(doc)).toList());
  }

  Stream<List<TicketMessage>> getMessagesForTicket(String ticketId) {
    return _firestore
        .collection('support_tickets').doc(ticketId).collection('messages')
        .orderBy('timestamp', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => TicketMessage.fromFirestore(doc)).toList());
  }
}
