import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/login_screen.dart';

import 'screens/employee_dashboard.dart';
// import 'screens/admin_dashboard.dart'; // Admin dashboard removed
import 'screens/verification_submission_screen.dart';
import 'screens/verification_status_screen.dart';
import 'screens/employee_profile_screen.dart';
import 'services/auth_service.dart';
import 'firebase_options.dart';
import 'splash_screen.dart';

void main() async {
  // Ensure that Flutter bindings are initialized
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const GhostEmployeeApp());
}

class GhostEmployeeApp extends StatelessWidget {
  const GhostEmployeeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ghost Employee Verification', // Updated title
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const SplashScreen(), // Show splash screen on startup
      routes: {
        '/profile': (context) => const EmployeeProfileScreen(),
        '/verification_submit': (context) => const VerificationSubmissionScreen(),
        '/verification_status': (context) => const VerificationStatusScreen(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    // Use LayoutBuilder to make decisions based on screen size
    return LayoutBuilder(
      builder: (context, constraints) {
        // Define a breakpoint for mobile devices
        const mobileBreakpoint = 600;
        final isMobile = constraints.maxWidth < mobileBreakpoint;

        return StreamBuilder<void>(
          stream: AuthService().onUserChanged,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            
            final authService = AuthService();
            return authService.isLoggedIn
                ? const EmployeeDashboard()
                : const LoginScreen();
          },
        );
      }
    );
  }
}
