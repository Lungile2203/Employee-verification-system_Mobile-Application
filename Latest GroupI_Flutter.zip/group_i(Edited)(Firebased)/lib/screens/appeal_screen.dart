import 'package:flutter/material.dart';
import '../services/verification_service.dart';

class AppealScreen extends StatefulWidget {
  final String verificationId;
  const AppealScreen({Key? key, required this.verificationId}) : super(key: key);

  @override
  State<AppealScreen> createState() => _AppealScreenState();
}

class _AppealScreenState extends State<AppealScreen> {
  final _ctrl = TextEditingController();
  bool _submitting = false;
  final VerificationService _service = VerificationService();

  void _submit() async {
    final msg = _ctrl.text.trim();
    if (msg.isEmpty) return;
    setState(() { _submitting = true; });
    final res = await _service.appealVerification(verificationId: widget.verificationId, message: msg);
    setState(() { _submitting = false; });
    if (res['success'] == true) {
      Navigator.of(context).pop('Appeal submitted.');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Appeal failed.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Submit Appeal')),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextField(controller: _ctrl, maxLines: 6, decoration: const InputDecoration(hintText: 'Explain why you think the rejection is incorrect')),
              const SizedBox(height: 12),
              _submitting ? const CircularProgressIndicator() : ElevatedButton(onPressed: _submit, child: const Text('Send Appeal')),
            ],
          ),
        ),
      ),
    );
  }
}
