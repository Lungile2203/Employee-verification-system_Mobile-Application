import 'package:flutter/material.dart';
import 'package:group_i/models/user_model.dart';
import 'package:group_i/services/auth_service.dart';
import 'package:group_i/services/verification_service.dart';
import 'edit_profile_screen.dart';
import 'submitted_documents_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final AuthService _authService = AuthService();
  final VerificationService _verificationService = VerificationService();

  @override
  Widget build(BuildContext context) {
    final user = _authService.currentUser;

    if (user == null) {
      return const Scaffold(body: Center(child: Text('No user logged in')));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: const Color(0xFF0B2E33),
        foregroundColor: Colors.white,
      ),
      backgroundColor: const Color(0xFF0B2E33),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              color: const Color(0xFF0B2E33).withBlue(55),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    // Display the employee's profile photo if available (use photoUrl regardless of verification)
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: const Color(0xFF93B1B5),
                      backgroundImage: (user is Employee && user.photoUrl != null && user.photoUrl!.isNotEmpty)
                          ? NetworkImage(user.photoUrl!)
                          : null,
                      child: (user is Employee && user.photoUrl != null && user.photoUrl!.isNotEmpty)
                          ? null
                          : const Icon(Icons.person, size: 50, color: Color(0xFF0B2E33)),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      user.fullName,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Employee-specific information
            if (user is Employee) _buildEmployeeInfo(user),

            // Admin-specific information
            if (user is Admin) _buildAdminInfo(user),

            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _editProfile,
                icon: const Icon(Icons.edit),
                label: const Text('Edit Profile'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF93B1B5),
                  foregroundColor: const Color(0xFF0B2E33),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ],
        ),
      ),
      );
  }

  Widget _buildEmployeeInfo(Employee employee) {
    return Card(
      color: const Color(0xFF0B2E33).withBlue(55),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Employee Information',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 16),
            _buildInfoRow('Phone Number', employee.phone),
            _buildInfoRow('Email', employee.email),
            _buildInfoRow('Role', employee.role),
            FutureBuilder<Map<String, dynamic>>(
              future: _verificationService.getEmployeeVerification(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return _buildInfoRow('Status', 'Loading...');
                }
                if (snapshot.hasData && snapshot.data?['hasVerification'] == true) {
                  final verification = snapshot.data!['verification'];
                  return _buildInfoRow('Status', verification.status);
                }
                // Fallback to the status on the employee object if the
                // specific verification document isn't found.
                return _buildInfoRow('Status', employee.status);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAdminInfo(Admin admin) {
    return Card(
      color: const Color(0xFF0B2E33).withBlue(55),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Administrator Information',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 16),
            _buildInfoRow('Admin ID', admin.userID),
            _buildInfoRow('Department', admin.department ?? 'Not specified'),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500, color: Colors.white70)),
          Flexible(
            child: Text(value,
                textAlign: TextAlign.end,
                style: const TextStyle(color: Colors.white54)),
          ),
        ],
      ),
    );
  }

  void _editProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const EditProfileScreen()),
    );
  }
}
