import 'package:flutter/material.dart';

class AdaptiveScaffold extends StatelessWidget {
  final String title;
  final List<Widget> screens;
  final List<BottomNavigationBarItem> destinations;
  final int currentIndex;
  final void Function(int) onNavigationIndexChange;
  final List<Widget>? actions;
  final FloatingActionButton? floatingActionButton;

  const AdaptiveScaffold({
    super.key,
    required this.title,
    required this.screens,
    required this.destinations,
    required this.currentIndex,
    required this.onNavigationIndexChange,
    this.actions,
    this.floatingActionButton,
  });

  @override
  Widget build(BuildContext context) {
    // Use LayoutBuilder to determine the screen width
    return LayoutBuilder(
      builder: (context, constraints) {
        // Define a breakpoint for mobile devices
        const mobileBreakpoint = 600;
        final bool isMobile = constraints.maxWidth < mobileBreakpoint;

        if (isMobile) {
          // Use BottomNavigationBar for mobile
          return Scaffold(
            appBar: AppBar(
              title: Text(title),
              backgroundColor: const Color(0xFF0B2E33),
              foregroundColor: Colors.white,
              elevation: 0,
              actions: actions,
            ),
            body: screens[currentIndex],
            backgroundColor: const Color(0xFF0B2E33),
            bottomNavigationBar: BottomNavigationBar(
              currentIndex: currentIndex,
              onTap: onNavigationIndexChange,
              backgroundColor: const Color(0xFF0B2E33).withOpacity(0.95),
              selectedItemColor: const Color(0xFF93B1B5),
              unselectedItemColor: Colors.white.withOpacity(0.6),
              items: destinations,
            ),
            floatingActionButton: floatingActionButton,
          );
        } else {
          // Use NavigationRail for wider screens (tablet/web/desktop)
          return Scaffold(
            appBar: AppBar(
              title: Text(title),
              backgroundColor: const Color(0xFF0B2E33),
              foregroundColor: Colors.white,
              elevation: 0,
              actions: actions,
            ),
            body: Row(
              children: [
                NavigationRail(
                  selectedIndex: currentIndex,
                  onDestinationSelected: onNavigationIndexChange,
                  labelType: NavigationRailLabelType.all,
                  backgroundColor: const Color(0xFF0B2E33),
                  selectedIconTheme: const IconThemeData(color: Color(0xFF93B1B5)),
                  unselectedIconTheme: IconThemeData(color: Colors.white.withOpacity(0.6)),
                  selectedLabelTextStyle: const TextStyle(color: Color(0xFF93B1B5)),
                  unselectedLabelTextStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
                  destinations: destinations.map((item) {
                    return NavigationRailDestination(icon: item.icon, label: Text(item.label!));
                  }).toList(),
                ),
                const VerticalDivider(thickness: 1, width: 1),
                Expanded(child: screens[currentIndex]),
              ],
            ),
            floatingActionButton: floatingActionButton,
          );
        }
      },
    );
  }
}