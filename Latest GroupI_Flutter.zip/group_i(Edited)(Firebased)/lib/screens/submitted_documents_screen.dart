// screens/submitted_documents_screen.dart
import 'package:flutter/material.dart';
import 'package:group_i/models/verification_model.dart';
import 'package:group_i/screens/document_viewer_screen.dart';
import 'package:group_i/services/auth_service.dart';
import 'package:group_i/services/verification_service.dart';
import 'package:group_i/models/verification_simple_model.dart';
class SubmittedDocumentsScreen extends StatefulWidget {
  final String? employeeId; // Used by admin to view other's docs

  const SubmittedDocumentsScreen({super.key, this.employeeId});

  @override
  State<SubmittedDocumentsScreen> createState() =>
      _SubmittedDocumentsScreenState();
}

class _SubmittedDocumentsScreenState extends State<SubmittedDocumentsScreen> {
  final AuthService _authService = AuthService();
  late Future<List<DocumentUpload>> _documentsFuture;
  List<DocumentUpload> _documents = [];
  List<DocumentUpload> _filteredDocuments = [];
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Use the passed employeeId for admins, or the current user's ID for employees
    final targetEmployeeId =
        widget.employeeId ?? _authService.currentUser?.userID;
    _documentsFuture = _authService.getDocumentsForEmployee(targetEmployeeId!);
    _searchController.addListener(_filterDocuments);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Submitted Documents'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      backgroundColor: const Color(0xFF0B2E33),
      body: FutureBuilder<List<DocumentUpload>>(
          future: _documentsFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              // No documents in employees/{id}/documents — try to fall back to the verifications collection
              return FutureBuilder<Map<String, dynamic>>(
                future: VerificationService().getEmployeeVerification(),
                builder: (context, verSnapshot) {
                  if (verSnapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (verSnapshot.hasError) return Center(child: Text('Error: ${verSnapshot.error}'));
                  if (verSnapshot.data == null || verSnapshot.data!['hasVerification'] != true) {
                    return _buildEmptyState();
                  }

                  final VerificationSimple verification = verSnapshot.data!['verification'] as VerificationSimple;
                  // Map verification URLs into DocumentUpload-like objects for the UI
                  _documents = [
                    DocumentUpload(
                      uploadId: verification.id + '_id',
                      requestId: verification.uid,
                      documentType: 'id_copy',
                      filePath: verification.idDocumentUrl,
                      fileName: 'ID Document',
                      fileSize: '0 MB',
                      uploadDate: verification.createdAt,
                      status: verification.status,
                    ),
                    DocumentUpload(
                      uploadId: verification.id + '_proof',
                      requestId: verification.uid,
                      documentType: 'employment_proof',
                      filePath: verification.proofUrl,
                      fileName: 'Proof of Residence',
                      fileSize: '0 MB',
                      uploadDate: verification.createdAt,
                      status: verification.status,
                    ),
                    DocumentUpload(
                      uploadId: verification.id + '_selfie',
                      requestId: verification.uid,
                      documentType: 'selfie',
                      filePath: verification.selfieUrl,
                      fileName: 'Selfie',
                      fileSize: '0 MB',
                      uploadDate: verification.createdAt,
                      status: verification.status,
                    ),
                  ];

                  // Initially, show all documents
                  if (_searchController.text.isEmpty) {
                    _filteredDocuments = _documents;
                  }

                  return Column(
                    children: [
                      _buildSearchBar(),
                      Expanded(child: _buildDocumentsList()),
                    ],
                  );
                },
              );
            }

            _documents = snapshot.data!;
            // Initially, show all documents
            if (_searchController.text.isEmpty) {
              _filteredDocuments = _documents;
            }

            return Column(
              children: [
                _buildSearchBar(),
                Expanded(child: _buildDocumentsList()),
              ],
            );
          }),
    );
  }

  void _filterDocuments() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredDocuments = _documents.where((doc) {
        final titleMatch = doc.documentTypeName.toLowerCase().contains(query);
        final fileNameMatch = doc.fileName.toLowerCase().contains(query);
        return titleMatch || fileNameMatch;
      }).toList();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: TextField(
        controller: _searchController,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: 'Search by type or filename...',
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
          prefixIcon: const Icon(Icons.search, color: Colors.white70),
          filled: true,
          fillColor: const Color(0xFF0B2E33).withBlue(55),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildStatsCard() {
    final verifiedCount =
        _documents.where((doc) => doc.status == 'verified').length;
    final pendingCount =
        _documents.where((doc) => doc.status == 'under_review').length;
    final totalCount = _documents.length;

    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildStatItem('Total', totalCount.toString(), Colors.blue.shade200),
            _buildStatItem('Verified', verifiedCount.toString(), Colors.green.shade300),
            _buildStatItem('Pending', pendingCount.toString(), Colors.orange.shade300),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(value,
            style: TextStyle(
                fontSize: 24, fontWeight: FontWeight.bold, color: color)),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    );
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.folder_open, size: 80, color: Colors.white38),
          SizedBox(height: 16),
          Text(
            'No documents submitted yet',
            style: TextStyle(fontSize: 16, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentsList() {
    if (_filteredDocuments.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32.0),
          child: Text('No matching documents found.',
              style: TextStyle(color: Colors.white70, fontSize: 16)),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredDocuments.length,
      itemBuilder: (context, index) {
        return _buildDocumentCard(_filteredDocuments[index]);
      },
    );
  }

  Widget _buildDocumentCard(DocumentUpload document) {
    Color statusColor;
    String statusText;

    switch (document.status) {
      case 'verified':
        statusColor = Colors.green;
        statusText = 'Verified';
        break;
      case 'rejected':
        statusColor = Colors.red;
        statusText = 'Rejected';
        break;
      case 'under_review':
        statusColor = Colors.orange;
        statusText = 'Under Review';
        break;
      default:
        statusColor = Colors.blue;
        statusText = 'Uploaded';
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () =>
            _viewDocument(document.documentTypeName, document.filePath),
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(document.documentIcon, size: 30, color: Colors.blue),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(document.documentTypeName,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 4),
                    Text(document.fileName,
                        style: const TextStyle(color: Colors.grey, fontSize: 14),
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(document.fileSize,
                            style: const TextStyle(
                                color: Colors.grey, fontSize: 12)),
                        const SizedBox(width: 8),
                        Text('•', style: TextStyle(color: Colors.grey[400])),
                        const SizedBox(width: 8),
                        Text(
                            '${document.uploadDate.day}/${document.uploadDate.month}/${document.uploadDate.year}',
                            style: const TextStyle(
                                color: Colors.grey, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(statusText,
                    style: TextStyle(
                        color: statusColor,
                        fontSize: 10,
                        fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
  void _viewDocument(String title, String url) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DocumentViewerScreen(documentTitle: title, documentUrl: url),
      ),
    );
  }
}
