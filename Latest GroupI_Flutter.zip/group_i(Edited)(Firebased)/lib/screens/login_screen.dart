import 'package:flutter/material.dart';
import 'package:group_i/services/auth_service.dart';

import 'help_icon_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  String _selectedRole = 'employee';
  bool _isLoading = false;
  bool _isPasswordObscured = true;

  // --- Dynamic Theme Colors ---
  static const Color _employeePrimaryColor = Colors.blue;
  static const Color _adminPrimaryColor = Color(0xFF36454F); // Charcoal
  static final Color _employeeBackgroundColor = Colors.grey[50]!;
  static final Color _adminBackgroundColor = Colors.grey[200]!;

  Color get _primaryColor =>
      _selectedRole == 'admin' ? _adminPrimaryColor : _employeePrimaryColor;

  Color get _backgroundColor => _selectedRole == 'admin'
      ? _adminBackgroundColor
      : _employeeBackgroundColor;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          HelpIconButton(
            title: 'Login Help',
            iconColor: _primaryColor,
            content: const Text(
              'Welcome to the Ghost Employee Verification System.\n\n'
              '1. If the Employee has never logged in before, Go to forgot passsword , use link to receive a reset email.\n'
              '2. Employees can log in with their Email.\n'
              ''
              'If you have forgotten your password, use the "Forgot Password?" link to receive a reset email.'
              'If you have forgotten your password, use the "Forgot Password?" link to receive a reset email.',
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500), // Constrain width for web/tablet
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 60),
                    Center(
                      child: CircleAvatar(
                        radius: 40, // Use dynamic color
                        backgroundColor: _primaryColor,
                        child: const Icon(
                          Icons.shield_outlined,
                          color: Colors.white,
                          size: 50,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Center(
                      child: Text(
                        'Ghost Employee Verification',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: _primaryColor, // Use dynamic color
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Center(
                      child: Text(
                        'Secure Employee Verification System',
                        style: TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                    ),
                    const SizedBox(height: 40),
                    Card(
                      elevation: 2,
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            DropdownButtonFormField<String>(
                              initialValue: _selectedRole,
                              decoration: const InputDecoration(
                                labelText: 'Login As',
                                border: OutlineInputBorder(),
                              ),
                              items: [
                                const DropdownMenuItem(
                                  value: 'employee',
                                  child: Row(
                                    children: [ // New Icon
                                      Icon(Icons.badge_outlined),
                                      SizedBox(width: 8),
                                      Text('Employee'),
                                    ],
                                  ),
                                ),
                              ],
                              onChanged: (value) {
                                setState(() {
                                  _selectedRole = value!;
                                });
                              },
                            ),
                            const SizedBox(height: 20),
                            if (_selectedRole == 'admin')
                              TextFormField(
                                controller: _emailController,
                                decoration: const InputDecoration(
                                  labelText: 'Email',
                                  border: OutlineInputBorder(),
                                  prefixIcon: Icon(Icons.email_outlined),
                                ),
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter your email';
                                  }
                                  // Per request, removing email validation.
                                  return null;
                                },
                              )
                            else
                              TextFormField(
                                controller: _emailController,
                                decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder(), prefixIcon: Icon(Icons.email_outlined)),
                                validator: (value) {
                                  if (_selectedRole == 'employee') {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter your email';
                                    }
                                    if (!value.contains('@')) {
                                      return 'Please enter a valid email';
                                    }
                                  }
                                  return null;
                                },
                              ),
                            const SizedBox(height: 20),
                            TextFormField(
                              controller: _passwordController,
                              obscureText: _isPasswordObscured,
                              decoration: InputDecoration(
                                labelText: 'Password',
                                border: const OutlineInputBorder(),
                                prefixIcon: const Icon(Icons.lock_outline),
                                suffixIcon: IconButton(
                                  icon: Icon(_isPasswordObscured
                                      ? Icons.visibility_off
                                      : Icons.visibility),
                                  onPressed: () => setState(() =>
                                      _isPasswordObscured = !_isPasswordObscured),
                                ),
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your password';
                                }
                                if (value.length < 6) {
                                  return 'Password must be at least 6 characters';
                                }
                                
                                return null;
                              },
                              onFieldSubmitted: (_) => _login(), // Moved inside TextFormField
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Align(
                                alignment: Alignment.centerRight,
                                child: TextButton(
                                  onPressed: _forgotPassword,
                                  child: const Text('Forgot Password?'),
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton(
                                onPressed: _isLoading ? null : _login,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _primaryColor, // Use dynamic color
                                ),
                                child: _isLoading
                                    ? const SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          valueColor: AlwaysStoppedAnimation<Color>(
                                            Colors.white,
                                          ),
                                        ),
                                      )
                                    : const Text(
                                        'Login',
                                        style: TextStyle(fontSize: 16),
                                      ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _login() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      final authService = AuthService();
      String result;

      if (_selectedRole == 'admin') {
        result = await authService.login(
          role: _selectedRole,
          email: _emailController.text.trim(),
          password: _passwordController.text,
        );
      } else {
        result = await authService.login(
          role: _selectedRole,
          password: _passwordController.text,
          loginIdentifier: _emailController.text.trim(),
        );
      }      
      if (mounted) {
        setState(() => _isLoading = false); // Stop loading indicator for other results
      }

      if (result != "Success" && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _forgotPassword() async {
    final identifierController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final isEmployee = _selectedRole == 'employee';

    return showDialog<void>(
      context: context, // The context from the builder
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Reset Password'),
          content: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Enter your email address to receive a password reset link.'),
                const SizedBox(height: 16),
                TextFormField(
                  controller: identifierController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    border: const OutlineInputBorder(),
                    prefixIcon: const Icon(Icons.email),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your identifier';
                    }
                    if (!value.contains('@')) {
                      return 'Please enter a valid email address';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              child: const Text('Send Link'),
              onPressed: () async {
                if (formKey.currentState!.validate()) {
                  final authService = AuthService();
                  final identifier = identifierController.text.trim();
                  final success = await authService.sendPasswordResetEmail(identifier);

                  if (mounted) {
                    Navigator.of(context).pop(); // Close dialog
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(success ? 'Password reset link sent to your registered email.' : 'Failed to send reset link.'),
                        backgroundColor: success ? Colors.green : Colors.red,
                      ),
                    );
                  }
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _showForgotPasswordError(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
