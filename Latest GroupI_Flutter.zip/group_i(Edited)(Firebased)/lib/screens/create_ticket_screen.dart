// screens/create_ticket_screen.dart
import 'package:flutter/material.dart';
import 'package:group_i/services/auth_service.dart';

class CreateTicketScreen extends StatefulWidget {
  const CreateTicketScreen({super.key});

  @override
  State<CreateTicketScreen> createState() => _CreateTicketScreenState();
}

class _CreateTicketScreenState extends State<CreateTicketScreen> {
  final _formKey = GlobalKey<FormState>();
  final _subjectController = TextEditingController();
  final _messageController = TextEditingController();
  final _authService = AuthService();
  bool _isSending = false;

  @override
  void dispose() {
    _subjectController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  Future<void> _sendTicket() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() => _isSending = true);

    final success = await _authService.createSupportTicket(
      subject: _subjectController.text.trim(),
      message: _messageController.text.trim(),
    );

    if (mounted) {
      setState(() => _isSending = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(success ? 'Support ticket created successfully.' : 'Failed to create ticket.'),
          backgroundColor: success ? Colors.green : Colors.red,
        ),
      );
      if (success) {
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Admin'),
        backgroundColor: const Color(0xFF0B2E33),
        foregroundColor: Colors.white,
      ),
      backgroundColor: const Color(0xFF0B2E33),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Create a new support request', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              const SizedBox(height: 8),
              const Text('An admin will respond to your request as soon as possible.', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 24),
              TextFormField(
                controller: _subjectController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(labelText: 'Subject', border: OutlineInputBorder(), labelStyle: TextStyle(color: Colors.white70)),
                validator: (v) => v!.isEmpty ? 'Subject is required' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _messageController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(labelText: 'Describe your issue...', border: OutlineInputBorder(), labelStyle: TextStyle(color: Colors.white70)),
                maxLines: 8,
                validator: (v) => v!.isEmpty ? 'A message is required' : null,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: _isSending ? null : _sendTicket,
                  icon: _isSending ? const SizedBox.shrink() : const Icon(Icons.send),
                  label: _isSending
                      ? const CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Colors.white))
                      : const Text('Send Request'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF93B1B5),
                    foregroundColor: const Color(0xFF0B2E33),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}