import 'package:flutter/material.dart';
import '../services/verification_service.dart';
import '../models/verification_simple_model.dart';
import 'appeal_screen.dart';
import 'help_icon_button.dart';

class VerificationStatusScreen extends StatefulWidget {
  const VerificationStatusScreen({Key? key}) : super(key: key);

  @override
  State<VerificationStatusScreen> createState() => _VerificationStatusScreenState();
}

class _VerificationStatusScreenState extends State<VerificationStatusScreen> {
  final VerificationService _service = VerificationService();
  bool _loading = true;
  VerificationSimple? _verification;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; });
    final res = await _service.getEmployeeVerification();
    if (res['hasVerification'] == true) {
      _verification = res['verification'] as VerificationSimple;
    } else {
      _verification = null;
    }
    setState(() { _loading = false; });
  }

  void _openAppeal() async {
    if (_verification == null) return;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AppealScreen(verificationId: _verification!.id)),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Verification Status'),
        backgroundColor: const Color(0xFF0B2E33),
        foregroundColor: Colors.white,
        actions: const [
          HelpIconButton(
            title: 'Understanding Your Status',
            iconColor: Colors.white,
            content: Text(
              'This screen shows the current status of your identity verification submission.\n\n'
              '• Pending: Your documents have been submitted and are awaiting review by an administrator.\n\n'
              '• Approved: Your identity has been successfully verified! You now have full access to your employee profile.\n\n'
              '• Rejected: Your submission could not be approved. Check the "Admin Comment" for details. You may be able to appeal the decision if the option is available.',
            ),
          ),
        ],
      ),
      backgroundColor: const Color(0xFF0B2E33),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: _loading
            ? const Center(
                child: Padding(
                padding: EdgeInsets.all(32.0),
                child: CircularProgressIndicator(color: Colors.white),
              ))
            : _verification == null
                ? _buildEmptyState()
                : _buildStatusStepper(_verification!),
        ),
      );
  }

  Widget _buildEmptyState() {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 64.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.folder_off_outlined, size: 80, color: Colors.white38),
          SizedBox(height: 16),
          Text(
            'No Verification Submitted',
            style: TextStyle(fontSize: 18, color: Colors.white70),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8),
          Text(
            'Please go to the verification screen to submit your documents.',
            style: TextStyle(color: Colors.white54),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildStatusStepper(VerificationSimple verification) {
    bool documentsSubmitted = verification.idDocumentUrl.isNotEmpty &&
                            verification.proofUrl.isNotEmpty &&
                            verification.selfieUrl.isNotEmpty;
                            
    int currentStep = 0;
    
    // Calculate appropriate step based on status and documents
    if (verification.status == 'approved') {
      currentStep = 3;
    } else if (verification.status == 'rejected') {
      currentStep = 2;
    } else if (documentsSubmitted) {
      currentStep = 1;
    }

    return Card(
      color: const Color(0xFF0B2E33).withBlue(55),
      shape: RoundedRectangleBorder(
        side: BorderSide(color: Colors.white.withOpacity(0.2)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Stepper(
              currentStep: currentStep,
              controlsBuilder: (context, details) => const SizedBox.shrink(),
              steps: [
                _buildStep(
                  title: 'Documents Required',
                  subtitle: documentsSubmitted ? 'All documents submitted' : 'Submit your verification documents',
                  step: 0,
                  currentStep: currentStep,
                  isSubmitted: documentsSubmitted,
                ),
                _buildStep(
                  title: 'Initial Review',
                  subtitle: currentStep > 0 ? 'Documents received' : 'Awaiting document submission',
                  step: 1,
                  currentStep: currentStep,
                  isSubmitted: currentStep > 0,
                ),
                _buildStep(
                  title: 'Document Validation',
                  subtitle: currentStep > 1 ? 'Documents under validation' : 'Pending review',
                  step: 2,
                  currentStep: currentStep,
                  isSubmitted: currentStep > 1,
                ),
                _buildStep(
                  title: 'Final Decision',
                  subtitle: _getAdminReviewSubtitle(verification.status),
                  step: 3,
                  currentStep: currentStep,
                  isSubmitted: verification.status != 'pending',
                ),
              ],
            ),
            if (verification.status == 'rejected') ...[
              const Divider(color: Colors.white24),
              _buildRejectionInfo(verification),
            ]
          ],
        ),
      ),
    );
  }

  Step _buildStep({
    required String title,
    required String subtitle,
    required int step,
    required int currentStep,
    required bool isSubmitted,
  }) {
    StepState state = StepState.indexed;
    if (step < currentStep || isSubmitted) {
      state = StepState.complete;
    } else if (step == currentStep) {
      state = StepState.editing;
    }

    return Step(
      title: Text(title, style: const TextStyle(color: Colors.white)),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white70)),
      content: const SizedBox.shrink(),
      state: state,
      isActive: step <= currentStep,
    );
  }

  String _getAdminReviewSubtitle(String status) {
      switch (status) {
      case 'approved':
        return '✓ Your verification has been approved!';
      case 'rejected':
        return '✗ Your verification was not approved';
      default:
        return '⋯ Under administrator review';
      }
  }



  Widget _buildRejectionInfo(VerificationSimple verification) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Column(
        children: [
          if (verification.comment != null && verification.comment!.isNotEmpty)
            _buildInfoRow(Icons.comment, 'Admin Comment:', verification.comment!),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _openAppeal,
            icon: const Icon(Icons.gavel),
            label: const Text('Appeal Decision'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orangeAccent, foregroundColor: Colors.black),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFF93B1B5), size: 18),
          const SizedBox(width: 12),
          Text(label, style: const TextStyle(color: Colors.white70)),
          const SizedBox(width: 8),
          Expanded(child: Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500), textAlign: TextAlign.end)),
        ],
      ),
    );
  }
}
