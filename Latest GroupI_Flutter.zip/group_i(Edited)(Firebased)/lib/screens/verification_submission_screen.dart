import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';

import '../services/verification_service.dart';
import 'help_icon_button.dart';

class VerificationSubmissionScreen extends StatefulWidget {
  const VerificationSubmissionScreen({Key? key}) : super(key: key);

  @override
  State<VerificationSubmissionScreen> createState() => _VerificationSubmissionScreenState();
}

class _VerificationSubmissionScreenState extends State<VerificationSubmissionScreen> {
  final VerificationService _service = VerificationService();
  final ImagePicker _picker = ImagePicker();

  PlatformFile? _idFile;
  PlatformFile? _proofFile;
  PlatformFile? _selfieFile;
  bool _isSubmitting = false;

  // Helper to convert XFile to PlatformFile
  Future<PlatformFile?> _xFileToPlatformFile(XFile? xFile) async {
    if (xFile == null) return null;
    return PlatformFile(
      name: xFile.name,
      size: await xFile.length(),
      path: xFile.path,
      bytes: await xFile.readAsBytes(),
    );
  }

  Future<void> _pickPdf(String type) async {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.picture_as_pdf),
                title: const Text('Choose PDF File'),
                onTap: () async {
                  Navigator.of(context).pop();
                  final result = await FilePicker.platform.pickFiles(
                    type: FileType.custom,
                    allowedExtensions: ['pdf'],
                    withData: true,
                  );
                  if (result != null && result.files.single.bytes != null) {
                    setState(() {
                      if (type == 'id') _idFile = result.files.single;
                      if (type == 'proof') _proofFile = result.files.single;
                    });
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _takeSelfie() async {
    final XFile? photo = await _picker.pickImage(
      source: ImageSource.camera,
      preferredCameraDevice: CameraDevice.front,
    );
    if (photo != null) {
      final platformFile = await _xFileToPlatformFile(photo);
      if (platformFile != null) {
        setState(() {
          _selfieFile = platformFile;
        });
      }
    }
  }

  Future<void> _submitVerification() async {
    if (_idFile == null || _proofFile == null || _selfieFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please upload all three documents before submitting.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    try {
      final res = await _service.submitVerification(
        idFile: _idFile!,
        proofFile: _proofFile!,
        selfieFile: _selfieFile!,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(res['message'] ?? 'Verification submitted.'),
            backgroundColor: res['success'] == true ? Colors.green : Colors.red,
          ),
        );

        if (res['success'] == true) {
          setState(() {
            _idFile = null;
            _proofFile = null;
            _selfieFile = null;
          });
          Navigator.pop(context);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('An error occurred during submission.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  Widget _uploadTile(String label, String type, IconData icon, VoidCallback onPick, bool isUploaded) {
    return ListTile(
      leading: Icon(icon, color: Colors.white.withOpacity(0.7)),
      title: Text(label, style: const TextStyle(fontWeight: FontWeight.w500, color: Colors.white)),
      subtitle: Text(
        type == 'selfie' ? 'Upload a clear photo of your face' : 'Upload a PDF document',
        style: TextStyle(color: Colors.white.withOpacity(0.7)),
      ),
      trailing: isUploaded
          ? const Icon(Icons.check_circle, color: Colors.green)
          : ElevatedButton(
              onPressed: onPick,
              child: Text(
                type == 'selfie' ? 'Capture' : 'Choose PDF',
              ),
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool allFilesSelected = _idFile != null && _proofFile != null && _selfieFile != null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Submit Verification'),
        backgroundColor: const Color(0xFF0B2E33),
        foregroundColor: Colors.white,
        actions: const [
          HelpIconButton(
            title: 'How to Submit Verification',
            iconColor: Colors.white,
            content: Text(
              'To verify your identity, please provide the following three items:\n\n'
              '1. ID Document: A clear photo or PDF of your official identification (e.g., National ID, Passport).\n\n'
              '2. Proof of Residence: A recent utility bill or bank statement (photo or PDF) showing your name and address. Must be less than 3 months old.\n\n'
              '3. Selfie: A clear, well-lit photo of your face, taken in real-time. Please remove hats or sunglasses.\n\n'
              'All documents must be clear and legible. File sizes should not exceed 50MB.\n\n'
              'Please upload all three documents before clicking Submit Verification.',
            ),
          ),
        ],
      ),
      backgroundColor: const Color(0xFF0B2E33),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _uploadTile(
                '1. ID Document',
                'id',
                Icons.credit_card,
                () => _pickPdf('id'),
                _idFile != null,
              ),
              _uploadTile(
                '2. Proof of Residence',
                'proof',
                Icons.home,
                () => _pickPdf('proof'),
                _proofFile != null,
              ),
              _uploadTile(
                '3. Selfie',
                'selfie',
                Icons.camera_alt,
                _takeSelfie,
                _selfieFile != null,
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: allFilesSelected && !_isSubmitting ? _submitVerification : null,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.blue,
                ),
                child: _isSubmitting
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                        'Submit Verification',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
