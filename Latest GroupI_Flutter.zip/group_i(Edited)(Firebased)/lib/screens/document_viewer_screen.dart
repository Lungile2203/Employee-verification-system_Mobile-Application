import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class DocumentViewerScreen extends StatefulWidget {
  final String documentTitle;
  final String documentUrl;

  const DocumentViewerScreen({super.key, required this.documentTitle, required this.documentUrl});

  @override
  State<DocumentViewerScreen> createState() => _DocumentViewerScreenState();
}

class _DocumentViewerScreenState extends State<DocumentViewerScreen> {
  bool _isImage = false;

  @override
  void initState() {
    super.initState();
    _checkFileType();
  }

  void _checkFileType() {
    // Check if the URL contains image extensions before the query parameters
    final Uri uri = Uri.parse(widget.documentUrl);
    final path = uri.path.toLowerCase();
    _isImage =
        path.endsWith('.jpg') || path.endsWith('.jpeg') || path.endsWith('.png') ||
        path.endsWith('.gif') || path.endsWith('.bmp') || path.endsWith('.webp');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.documentTitle),
        backgroundColor: const Color(0xFF0B2E33),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: () => _openUrl(widget.documentUrl),
            tooltip: 'Download',
          ),
        ],
      ),
      backgroundColor: const Color(0xFF0B2E33),
      body: _buildDocumentViewer(),
    );
  }

  Widget _buildDocumentViewer() {
    if (_isImage && !kIsWeb) {
      return _buildImageViewer();
    } else {
      // On web, or for non-image files, show a generic viewer
      return _buildGenericDocumentViewer();
    }
  }

  Widget _buildImageViewer() {
    return InteractiveViewer(
      panEnabled: true,
      boundaryMargin: const EdgeInsets.all(20),
      minScale: 0.1,
      maxScale: 4.0,
      child: Center(
        child: Image.network(
          widget.documentUrl,
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) return child;
            return const Center(child: CircularProgressIndicator());
          },
          fit: BoxFit.contain,
          errorBuilder: (context, error, stackTrace) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 16),
                  const Text('Could not load image.', style: TextStyle(color: Colors.white70)),
                ],
              ),
            );
          },
      ),
    ),
    );
  }

  Widget _buildGenericDocumentViewer() {
    return Container(
      margin: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF0B2E33).withBlue(55),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(_isImage ? Icons.image : Icons.picture_as_pdf, size: 80, color: _isImage ? Colors.blueAccent : Colors.redAccent),
          const SizedBox(height: 16),
          Text(
            _isImage ? 'Image Document' : 'PDF Document',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white),
          ),
          const SizedBox(height: 8),
          Text(
            kIsWeb ? 'Opening documents in-app is not supported on the web.' : 'This document type cannot be previewed.',
            style: TextStyle(color: Colors.white70),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => _openUrl(widget.documentUrl),
            icon: const Icon(Icons.open_in_new),
            label: const Text('Open in Browser/App'),
          ),
        ],
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not open document.')));
    }
  }
}
