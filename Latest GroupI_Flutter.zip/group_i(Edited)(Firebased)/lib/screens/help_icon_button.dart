// widgets/help_icon_button.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class HelpIconButton extends StatelessWidget {
  final String title;
  final Widget content;
  final Color? iconColor;
  static const String adminEmail = '222078272@stud.cut.ac.za';

  const HelpIconButton({
    super.key,
    required this.title,
    required this.content,
    this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.help_outline, color: iconColor),
      tooltip: 'Help',
      onPressed: () {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text(title),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    content,
                    const SizedBox(height: 16),
                    const Text('Need help? Contact the admin:', style: TextStyle(fontWeight: FontWeight.bold)),
                    InkWell(
                      onTap: () {
                        Clipboard.setData(const ClipboardData(text: adminEmail)).then((_) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Admin email copied to clipboard')),
                          );
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.0),
                        child: Row(
                          children: [
                            Expanded(child: Text(adminEmail, style: const TextStyle(color: Colors.blue))),
                            const Icon(Icons.copy, size: 16, color: Colors.blue),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  child: const Text('OK'),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            );
          },
        );
      },
    );
  }
}